﻿using System;
using System.Globalization;
using System.Xml;
using System.Xml.XPath;
using UIH.Mcsf.Core;

namespace UIH.Mcsf.Filming.Configure
{
    public class PageTitleConfigure
    {
        public static readonly PageTitleConfigure Instance = new PageTitleConfigure();

        private PageTitleConfigure()
        {
            ParseFilmingPageConfig();
        }


        private void SetValueFromDicomString(string attrName,string attrValue)
        {
            switch (attrName)
            {
                case "DisplayFont":
                    DisplayFont = Convert.ToDouble(attrValue);
                    break;
                case "DisplayPosition":
                    DisplayPosition = attrValue;
                    break;
                case "PatientName":
                    PatientName = attrValue;
                    break;
                case "PatientID":
                    PatientID = attrValue;
                    break;
                //case "StudyID":
                //    StudyIdFlag = attrValue;
                    //break;
                case "Age":
                    Age = attrValue;
                    break;
                case "Sex":
                    Sex = attrValue;
                    break;
                case "StudyDate":
                    StudyDate = attrValue;
                    break;
                case "HospitalInfo":
                    HospitalInfo = attrValue;
                    break;
                case "OperatorName":
                    OperatorName = attrValue;
                    break;
                case "Comment":
                    Comment = attrValue;
                    break;
                case "PageNo":
                    PageNo = attrValue;
                    break;
                case "AccessionNo":
                    AccessionNo = attrValue;
                    break;
            }
        }

        public double DisplayFont { get; private set; }
        public string DisplayPosition { get; private set; }
        public string PatientName { get; private set; }
        public string PatientID { get; private set; }
        public string Age { get; private set; }
        public string Sex { get; private set; }
        public string StudyDate { get; private set; }
        public string HospitalInfo { get; private set; }
        public string OperatorName { get; private set; }
        public string Comment { get; private set; }
        public string PageNo { get; private set; }
        public string AccessionNo { get; private set; }
        public void ParseFilmingPageConfig()
        {
            var configureFilePath = mcsf_clr_systemenvironment_config.GetApplicationPath("FilmingConfigPath") + "FilmingPage.xml";
            try
            {
                Logger.LogFuncUp();
                var doc = new XmlDocument();
                doc.Load(configureFilePath);
                var xNav = doc.CreateNavigator();
                var xPathIt = xNav.Select("//FilmingPage");
                //use the XPathNodeIterator to display the results
                if (xPathIt.Count > 0)
                {
                    while (xPathIt.MoveNext())
                    {
                        var nodesNavigator = xPathIt.Current;
                        var currentItem = nodesNavigator.SelectDescendants(XPathNodeType.All, false);

                        while (currentItem.MoveNext())
                        {
                            SetValueFromDicomString(currentItem.Current.Name, currentItem.Current.Value);
                        }
                    }
                }
                else
                {
                    Logger.LogWarning("No titles found in catalog.");
                }
                Logger.LogFuncDown();
            }
            catch (Exception ex)
            {
                Logger.LogFuncException(ex.Message);
                Logger.Instance.LogDevWarning("[Fail to parse file]" + configureFilePath);
          //      Logger.Instance.LogSvcWarning(Logger.LogUidSource, FilmingSvcLogUid.LogUidSvcWarnConfigureFile,
          //"[Fail to parse file]" + configureFilePath);
            }
        }

        #region [Jinyang.li Performance]

        public void SerializeToXml(XmlNode parentNode)
        {
            if (null == parentNode || null == parentNode.OwnerDocument)
            {
                return;
            }

            var filmingPageTitleInfoNode = parentNode.OwnerDocument.CreateElement(OffScreenRenderXmlHelper.FILMING_PAGE_TITLE_SETTING);
            parentNode.AppendChild(filmingPageTitleInfoNode);

            OffScreenRenderXmlHelper.AppendChildNode(filmingPageTitleInfoNode, OffScreenRenderXmlHelper.DISPLAY_FONT, this.DisplayFont.ToString(CultureInfo.InvariantCulture));
            OffScreenRenderXmlHelper.AppendChildNode(filmingPageTitleInfoNode, OffScreenRenderXmlHelper.DISPLAY_POSITION, this.DisplayPosition);
            OffScreenRenderXmlHelper.AppendChildNode(filmingPageTitleInfoNode, OffScreenRenderXmlHelper.PATIENT_NAME_FLAG, this.PatientName);
            OffScreenRenderXmlHelper.AppendChildNode(filmingPageTitleInfoNode, OffScreenRenderXmlHelper.PATIENT_ID_FLAG, this.PatientID);
            OffScreenRenderXmlHelper.AppendChildNode(filmingPageTitleInfoNode, OffScreenRenderXmlHelper.AGE_FLAG, this.Age);
            OffScreenRenderXmlHelper.AppendChildNode(filmingPageTitleInfoNode, OffScreenRenderXmlHelper.SEX_FLAG, this.Sex);
            OffScreenRenderXmlHelper.AppendChildNode(filmingPageTitleInfoNode, OffScreenRenderXmlHelper.STUDY_DATE_FLAG, this.StudyDate);
            OffScreenRenderXmlHelper.AppendChildNode(filmingPageTitleInfoNode, OffScreenRenderXmlHelper.HOSPITAL_INFO_FLAG, this.HospitalInfo != "1" && this.OperatorName != "1" ? "0" : "1");
            OffScreenRenderXmlHelper.AppendChildNode(filmingPageTitleInfoNode, OffScreenRenderXmlHelper.COMMENT, this.Comment);
            OffScreenRenderXmlHelper.AppendChildNode(filmingPageTitleInfoNode, OffScreenRenderXmlHelper.PAGE_NO, this.PageNo);
            OffScreenRenderXmlHelper.AppendChildNode(filmingPageTitleInfoNode, OffScreenRenderXmlHelper.ACCESSION_NO, this.AccessionNo);
        }

       #endregion
    }
}
