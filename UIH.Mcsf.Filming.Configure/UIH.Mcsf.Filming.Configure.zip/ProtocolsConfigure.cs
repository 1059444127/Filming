﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using UIH.Mcsf.Core;
using UIH.Mcsf.Filming.Interface;

namespace UIH.Mcsf.Filming.Configure
{
    public class ProtocolsConfigure : AbstractConfigure
    {

        public ProtocolsConfigure(string fileName) : base(fileName)
        {
            Logger.Instance.LogDevInfo(FilmingUtility.FunctionTraceEnterFlag + "[ProtocolsConfigure.ProtocolsConfigure]" + "[fileName]" );
            Protocols = new List<Protocol>();
            ParseConfigures();
        }

        public IList<Protocol> Protocols { get; private set; }

        protected override void ReadConfigures(IFileParserCSharp fileParser)
        {
            try
            {
                Logger.Instance.LogDevInfo(FilmingUtility.FunctionTraceEnterFlag + "[ProtocolsConfigure.ReadConfigures]" + "[fileParser]" );

                int protocolCount;

                if(!fileParser.GetElementNumber("/Protocol", out protocolCount) || protocolCount == 0)
                {
                    Logger.Instance.LogDevWarning("[No protocol parsed from configure file] " + FilePath);
          //          Logger.Instance.LogSvcWarning(Logger.LogUidSource, FilmingSvcLogUid.LogUidSvcWarnConfigureFile,
          //"[No protocol parsed from configure file] " + FilePath);
                    return;
                }

                Protocols = new List<Protocol>();
                for (int i = 0; i < protocolCount; i++)
                {
                    var path = string.Format("/Protocol[{0}]", i);
                    var name = fileParser.GetAttributeStringValue(path, "Name");
                    var layout = fileParser.GetAttributeStringValue(path, "Layout");
                    //var sRows = fileParser.GetAttributeStringValue(path, "Rows");
                    //var sCols = fileParser.GetAttributeStringValue(path, "Columns");
                    Protocols.Add(ProtocolFactory.Instance.CreateProtocol(name, layout));
                }

            }
            catch (Exception e)
            {
                Logger.Instance.LogDevWarning("[ProtocolsConfigure.ReadConfigures]" + "[Exception]" + e + "[Message]" + e.Message);
                //if(Protocols != null) Protocols.Clear();
            }
            Protocols = (from protocol in Protocols
                         orderby protocol.Name.ToUpper() 
                         select protocol).ToList();

        }

	    public void WriteBack(Collection<Protocol> protocols)
	    {
            Logger.Instance.LogDevInfo(FilmingUtility.FunctionTraceEnterFlag + "[ProtocolsConfigure.WriteBack]" + "[protocols]" );
            foreach (var protocol in protocols)
            {
                Logger.Instance.LogDevInfo(protocol.ToString());
            }

            var fileParser = ConfigParserFactory.Instance().CreateCSharpFileParser();

		    try
		    {
			    var protocolList = protocols.ToList();

			    fileParser.Initialize();

			    if (!fileParser.ParseByURI(FilePath))
			    {
				    Logger.Instance.LogDevWarning("[Fail to parse file]" + FilePath);
          //          Logger.Instance.LogSvcWarning(Logger.LogUidSource, FilmingSvcLogUid.LogUidSvcWarnConfigureFile,
          //"[Fail to parse file]" + FilePath);
			    }

                int protocolCount;

                if (!fileParser.GetElementNumber("/Protocol", out protocolCount) || protocolCount == 0)
                {
                    Logger.Instance.LogDevWarning("[No protocol parsed from configure file]" + FilePath);
          //          Logger.Instance.LogSvcWarning(Logger.LogUidSource, FilmingSvcLogUid.LogUidSvcWarnConfigureFile,
          //"[No protocol parsed from configure file]" + FilePath);
                }


                //Change older layout
			    int i = 0;
                for (; i < protocolCount; i++)
                {
                    var path = string.Format("/Protocol[{0}]", i);
                    var name = fileParser.GetAttributeStringValue(path, "Name");

	                var protocol = protocolList.Find(p => p.Name == name);
	                if (null == protocol) continue;

	                var layout = protocol.Layout.ToString();
	                if (!fileParser.SetAttributeStringValue(path, "Layout", layout))
	                {
		                Logger.Instance.LogDevWarning("[Fail to set layout][Name]" + name + "[Layout]" + layout);
          //              Logger.Instance.LogSvcWarning(Logger.LogUidSource, FilmingSvcLogUid.LogUidSvcWarnConfigureFile,
          //"[Fail to set layout][Name]" + name + "[Layout]" + layout + "[From file]" + FilePath);
                    }

	                protocolList.Remove(protocol);
                }
                
                //MayBe need to add new layout


			    if (!fileParser.SaveDocument())
			    {
				    Logger.Instance.LogDevWarning("[Fail to Save Config file]" + FilePath);
                    Logger.Instance.LogSvcWarning(Logger.LogUidSource, FilmingSvcLogUid.LogUidSvcWarnConfigureFile,
          "[Fail to Save Config file]" + FilePath);
			    }
		    }
		    catch (Exception e)
		    {
                Logger.Instance.LogDevWarning("[ProtocolsConfigure.WriteBack]" + "[Exception]" + e + "[Message]" + e.Message);
		    }
		    finally
		    {
                fileParser.Terminate();
		    }

	    }

    }
}
