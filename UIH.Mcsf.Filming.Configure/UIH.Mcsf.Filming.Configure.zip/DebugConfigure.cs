namespace UIH.Mcsf.Filming.Configure
{
    public class DebugConfigure : AbstractFlatConfigure
    {

        public DebugConfigure(string filePath) : base(filePath, true)
        {
        }

	    // ReSharper disable once UnusedAutoPropertyAccessor.Local
        public bool StandAlone { get; private set; }
        public int PrinterDPI { get; private set; } 
    }
}