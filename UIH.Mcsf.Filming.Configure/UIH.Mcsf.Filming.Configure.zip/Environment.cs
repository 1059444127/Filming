﻿using System.Windows;
using UIH.Mcsf.Core;
using UIH.Mcsf.NLS;

namespace UIH.Mcsf.Filming.Configure
{
    public class Environment
    {
        #region [--Singleton--]

        private static volatile Environment _instance;
        private static readonly object LockHelper = new object();
        private DebugConfigure _debugConfigure;
        private ProtocolsConfigure _protocolsConfigure;

        public static Environment Instance
        {
            get
            {
                if (_instance == null)
                {
                    lock (LockHelper)
                    {
                        if (_instance == null)
                            _instance = new Environment();
                    }
                }
                return _instance;
            }
        }

        #endregion //[--Singleton--]


        private Environment()
        {
            var entryPath = mcsf_clr_systemenvironment_config.GetApplicationPath(FilmingConfigureString);
            if (entryPath == string.Empty) entryPath = DefaultEntryPath;
            FilmingConfigurePath = entryPath + FilmingConfigureFileName;
            MiscellaneousConfigurePath = entryPath + MiscellaneousConfigureFileName;
            FilmTitleConfigurePath = entryPath + FilmTitleConfigureFileName;
            PrintersConfigurePath = entryPath + PrintersConfigureFileName;
            WindowLevelAndWidthConfigurePath = entryPath + WindowLevelAndWidthConfigureRelativePath;
            FilmingLogConfigurePath = entryPath + FilmingLogConfigureFileName;
            DebugConfigurePath = entryPath + DebugConfigureFileName;

            string modalityName;
            mcsf_clr_systemenvironment_config.GetModalityName(out modalityName);
            Modality = modalityName;

            var protocolsConfigureFilePathSuffix = GetProtocolsConfigureFilePathSuffix(modalityName);

            ProtocolsConfigureFilePath = entryPath + ProtocolsConfigureFileName + protocolsConfigureFilePathSuffix + ".xml";
        }

        private string GetProtocolsConfigureFilePathSuffix(string modalityName)
        {
            var suffix = modalityName.ToUpper();
            //if (suffix == "CT" || suffix == "PT") suffix = "CTPT";
            return "For"+suffix;
        }

        #region [--Path--]

        public string FilmingConfigurePath { get; private set; }
        public string MiscellaneousConfigurePath { get; private set; }
        public string FilmTitleConfigurePath { get; private set; }
        public string PrintersConfigurePath { get; private set; }
        public string WindowLevelAndWidthConfigurePath { get; private set; }
        public string FilmingLogConfigurePath { get; private set; }
        public string DebugConfigurePath { get; private set; }
        public string ProtocolsConfigureFilePath { get; private set; }
        /// <summary>
        /// Zhenghe Modality, for example : CT / MR
        /// </summary>
        public string Modality { get; private set; }

        private const string FilmingConfigureString = "FilmingConfigPath";
        private const string FilmingConfigureFileName = "McsfFilming.xml";
        private const string MiscellaneousConfigureFileName = "Miscellaneous.xml";
        private const string FilmTitleConfigureFileName = "FilmingPage.xml";
        private const string PrintersConfigureFileName = "PrinterConfig.xml";
        private const string WindowLevelAndWidthConfigureRelativePath = "..\\..\\appcommon\\config\\app_miscellaneous.xml";
        private const string FilmingLogConfigureFileName = "McsfFilmingLog.xml";
        private const string DebugConfigureFileName = "\\Debug\\McsfFilmingDebug.xml";
        private const string ProtocolsConfigureFileName = "ProtocolBindingLayouts";

        private const string DefaultEntryPath = @"D:\UIH\appdata\filming\config\";
	    private const string FilmingNlsResourceName = "Filming";

        #endregion //[--Path--]

        public DebugConfigure GetDebugConfigure()
        {
            return _debugConfigure ?? (_debugConfigure = new DebugConfigure(DebugConfigurePath));
        }

        public ProtocolsConfigure GetProtocolsConfig()
        {
            return _protocolsConfigure ?? (_protocolsConfigure = new ProtocolsConfigure(ProtocolsConfigureFilePath));
        }

        public void ReloadProtocolsConfig()
        {
            if (_protocolsConfigure != null)
            {
                _protocolsConfigure.ParseConfigures();
            }
        }


	    public ResourceDictionary GetFilmingNlsDictionary()
	    {
		    return _filmingNlsDictionary ?? (_filmingNlsDictionary = ResourceMgr.Instance().Init(FilmingNlsResourceName));
	    }

	    //        if(_filmingResDict == null)
                //{
                //    ResourceMgr nls = ResourceMgr.Instance();
                //    _filmingResDict = nls.Init("Filming");
                //}

                //return _filmingResDict;
	    private ResourceDictionary _filmingNlsDictionary;
    }
}
